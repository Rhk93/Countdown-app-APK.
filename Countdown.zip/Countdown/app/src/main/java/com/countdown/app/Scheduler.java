package com.countdown.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class Scheduler {
    public static final String CH = "countdown";

    public static void reschedule(Context ctx) {
        reschedule(ctx, System.currentTimeMillis());
    }

    public static void reschedule(Context ctx, long after) {
        List<Item> items = Store.load(ctx);
        long min = Long.MAX_VALUE;
        for (Item it : items) {
            it.nextAt = it.computeNext(after);
            if (it.nextAt > 0 && it.nextAt < min) min = it.nextAt;
        }
        Store.save(ctx, items);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(ctx, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 0, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (min == Long.MAX_VALUE) return;
        try {
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, min, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, min, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, min, pi);
        }
    }

    public static void channel(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Promemoria scadenze",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Avvisi dei countdown");
        nm.createNotificationChannel(ch);
    }

    public static String dateText(Item it) {
        return new SimpleDateFormat("EEE d MMM yyyy", Locale.ITALIAN).format(it.deadline().getTime());
    }

    public static void show(Context ctx, Item it) {
        channel(ctx);
        int left = it.daysLeft();
        String msg = left == 0 ? "⏰ Oggi è la scadenza!"
                : left == 1 ? "⏳ Domani è la scadenza"
                : "⏳ Mancano " + left + " giorni";
        msg += " · " + dateText(it);
        String big = it.note.isEmpty() ? msg : msg + "\n" + it.note;
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, (int) (it.id % 1000000000L), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(ctx, CH)
                .setSmallIcon(R.drawable.notifica)
                .setContentTitle(it.title.isEmpty() ? "Countdown" : it.title)
                .setContentText(msg)
                .setStyle(new Notification.BigTextStyle().bigText(big))
                .setAutoCancel(true)
                .setContentIntent(pi);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((int) (it.id % 1000000000L), b.build());
    }
}
