package com.countdown.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class Item {
    public long id;
    public String title = "", note = "";
    public int y, m, d;
    public boolean notify = true;
    public List<Integer> times = new ArrayList<>();
    public int everyDays = 1;
    public int startBefore = -1;
    public long nextAt = 0;

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("title", title); o.put("note", note);
        o.put("y", y); o.put("m", m); o.put("d", d);
        o.put("notify", notify);
        JSONArray a = new JSONArray();
        for (int t : times) a.put(t);
        o.put("times", a);
        o.put("every", everyDays); o.put("start", startBefore); o.put("next", nextAt);
        return o;
    }

    public static Item fromJson(JSONObject o) {
        Item i = new Item();
        i.id = o.optLong("id"); i.title = o.optString("title", ""); i.note = o.optString("note", "");
        i.y = o.optInt("y"); i.m = o.optInt("m"); i.d = o.optInt("d");
        i.notify = o.optBoolean("notify", true);
        JSONArray a = o.optJSONArray("times");
        if (a != null) for (int k = 0; k < a.length(); k++) i.times.add(a.optInt(k));
        i.everyDays = Math.max(1, o.optInt("every", 1));
        i.startBefore = o.optInt("start", -1);
        i.nextAt = o.optLong("next", 0);
        return i;
    }

    public static Calendar midnight(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    public Calendar deadline() {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m, d, 0, 0, 0);
        return c;
    }

    public static int daysBetween(Calendar a, Calendar b) {
        return (int) Math.round((b.getTimeInMillis() - a.getTimeInMillis()) / 86400000.0);
    }

    public int daysLeft() {
        return daysBetween(midnight(System.currentTimeMillis()), deadline());
    }

    private boolean dayOk(int left) {
        if (left < 0) return false;
        if (startBefore >= 0 && left > startBefore) return false;
        return left % Math.max(1, everyDays) == 0;
    }

    private List<Integer> sortedTimes() {
        List<Integer> s = new ArrayList<>(times);
        Collections.sort(s);
        return s;
    }

    /** Prossimo momento di notifica dopo "after" (0 = nessuno). */
    public long computeNext(long after) {
        if (!notify || times.isEmpty()) return 0;
        Calendar today = midnight(after);
        int total = daysBetween(today, deadline());
        List<Integer> ts = sortedTimes();
        for (int i = 0; i <= total; i++) {
            if (!dayOk(total - i)) continue;
            for (int t : ts) {
                Calendar c = (Calendar) today.clone();
                c.add(Calendar.DAY_OF_MONTH, i);
                c.set(Calendar.HOUR_OF_DAY, t / 60);
                c.set(Calendar.MINUTE, t % 60);
                if (c.getTimeInMillis() > after) return c.getTimeInMillis();
            }
        }
        return 0;
    }

    /** Quante notifiche arriveranno ancora fino alla scadenza. */
    public int countRemaining(long after) {
        if (!notify || times.isEmpty()) return 0;
        Calendar today = midnight(after);
        int total = daysBetween(today, deadline());
        int n = 0;
        for (int i = 0; i <= total; i++) {
            if (!dayOk(total - i)) continue;
            for (int t : times) {
                Calendar c = (Calendar) today.clone();
                c.add(Calendar.DAY_OF_MONTH, i);
                c.set(Calendar.HOUR_OF_DAY, t / 60);
                c.set(Calendar.MINUTE, t % 60);
                if (c.getTimeInMillis() > after) n++;
            }
        }
        return n;
    }

    public String summary() {
        if (!notify || times.isEmpty()) return "🔕 Notifiche spente";
        String s = "🔔 " + times.size() + (times.size() == 1 ? " volta" : " volte") + " al giorno";
        if (everyDays > 1) s += ", ogni " + everyDays + " giorni";
        if (startBefore >= 0) s += ", da " + startBefore + (startBefore == 1 ? " giorno" : " giorni") + " prima";
        return s;
    }
}
