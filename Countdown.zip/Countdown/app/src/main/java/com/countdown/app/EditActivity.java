package com.countdown.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class EditActivity extends Activity {
    Theme t;
    Item item;
    boolean isNew;
    List<Item> all;
    EditText titleEt, noteEt;
    TextView dateTv, notifyTv, perDayTv, everyTv, startTv, countTv;
    LinearLayout timesBox;

    static final String[] EVERY_LABELS = {"Ogni giorno", "Ogni 2 giorni", "Ogni 3 giorni", "Ogni settimana", "Ogni 2 settimane", "Ogni mese"};
    static final int[] EVERY_VALUES = {1, 2, 3, 7, 14, 30};
    static final String[] START_LABELS = {"Da subito", "1 giorno prima", "2 giorni prima", "3 giorni prima", "1 settimana prima", "2 settimane prima", "1 mese prima"};
    static final int[] START_VALUES = {-1, 1, 2, 3, 7, 14, 30};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        t = Theme.get(this);
        all = Store.load(this);
        item = Store.find(all, getIntent().getLongExtra("id", -1));
        if (item == null) {
            isNew = true;
            item = new Item();
            item.id = System.currentTimeMillis();
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, 7);
            item.y = c.get(Calendar.YEAR);
            item.m = c.get(Calendar.MONTH);
            item.d = c.get(Calendar.DAY_OF_MONTH);
            item.times.add(9 * 60);
        }
        build();
    }

    EditText edit(String hint, String value, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setBackground(null);
        e.setTextColor(t.text);
        e.setHintTextColor(t.sub);
        e.setTypeface(t.font);
        e.setTextSize(17 * t.scale);
        e.setPadding(0, t.dp(14), 0, t.dp(14));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        return e;
    }

    void build() {
        ScrollView sv = new ScrollView(this);
        t.applyWindow(this, sv);
        LinearLayout col = t.column();
        sv.addView(col);

        LinearLayout bar = t.bar("Annulla", isNew ? "Nuovo" : "Modifica", "Salva");
        bar.getChildAt(0).setOnClickListener(v -> finish());
        bar.getChildAt(2).setOnClickListener(v -> save());
        col.addView(bar);

        col.addView(t.label("COSA DEVI RICORDARE"));
        LinearLayout g1 = t.group();
        titleEt = edit("Es. Pagare la bolletta", item.title, false);
        noteEt = edit("Note (facoltative)", item.note, true);
        g1.addView(titleEt);
        g1.addView(t.divider());
        g1.addView(noteEt);
        col.addView(g1);

        col.addView(t.label("SCADENZA"));
        LinearLayout g2 = t.group();
        dateTv = t.row(g2, "📅  Data", v -> pickDate());
        col.addView(g2);

        col.addView(t.label("NOTIFICHE"));
        LinearLayout g3 = t.group();
        notifyTv = t.row(g3, "🔔  Notifiche", v -> { item.notify = !item.notify; refresh(); });
        perDayTv = t.row(g3, "Quante volte al giorno", v -> pickPerDay());
        everyTv = t.row(g3, "Quali giorni", v -> pickEvery());
        startTv = t.row(g3, "Inizia ad avvisare", v -> pickStart());
        col.addView(g3);

        col.addView(t.label("ORARI DELLE NOTIFICHE"));
        LinearLayout g4 = t.group();
        timesBox = new LinearLayout(this);
        timesBox.setOrientation(LinearLayout.VERTICAL);
        g4.addView(timesBox);
        g4.addView(t.divider());
        TextView add = t.tv("+  Aggiungi orario", 16, true, t.accent);
        add.setPadding(0, t.dp(14), 0, t.dp(14));
        add.setOnClickListener(v -> pickTime(-1));
        g4.addView(add);
        col.addView(g4);

        countTv = t.tv("", 14, false, t.dark ? t.sub : Theme.withAlpha(t.text, 170));
        countTv.setPadding(t.dp(16), t.dp(12), t.dp(16), 0);
        col.addView(countTv);

        if (!isNew) {
            TextView del = t.tv("Elimina countdown", 17, true, 0xFFFF3B30);
            del.setGravity(Gravity.CENTER);
            del.setBackground(Theme.round(t.card, t.dp(16)));
            del.setPadding(0, t.dp(16), 0, t.dp(16));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = t.dp(30);
            del.setOnClickListener(v -> new AlertDialog.Builder(this, t.dialogTheme())
                    .setTitle("Eliminare questo countdown?")
                    .setPositiveButton("Elimina", (d, w) -> delete())
                    .setNegativeButton("Annulla", null).show());
            col.addView(del, lp);
        }
        setContentView(sv);
        refresh();
    }

    static String hm(int m) {
        return String.format(Locale.ITALIAN, "%02d:%02d", m / 60, m % 60);
    }

    void refresh() {
        Collections.sort(item.times);
        dateTv.setText(Scheduler.dateText(item));
        notifyTv.setText(item.notify ? "● Attive" : "○ Spente");
        notifyTv.setTextColor(item.notify ? t.accent : t.sub);
        perDayTv.setText(item.times.size() + (item.times.size() == 1 ? " volta" : " volte"));
        everyTv.setText(labelFor(EVERY_VALUES, EVERY_LABELS, item.everyDays, "Ogni " + item.everyDays + " giorni"));
        startTv.setText(labelFor(START_VALUES, START_LABELS, item.startBefore, item.startBefore + " giorni prima"));

        timesBox.removeAllViews();
        for (int i = 0; i < item.times.size(); i++) {
            final int idx = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(0, t.dp(12), 0, t.dp(12));
            r.addView(t.tv("🕘  " + hm(item.times.get(i)), 17, false, t.text), new LinearLayout.LayoutParams(0, -2, 1));
            TextView x = t.tv("✕", 18, false, t.sub);
            x.setPadding(t.dp(16), 0, t.dp(4), 0);
            x.setOnClickListener(v -> { item.times.remove(idx); refresh(); });
            r.addView(x);
            r.setOnClickListener(v -> pickTime(idx));
            if (i > 0) timesBox.addView(t.divider());
            timesBox.addView(r);
        }

        long now = System.currentTimeMillis();
        int n = item.countRemaining(now);
        long next = item.computeNext(now);
        String s;
        if (!item.notify) s = "Le notifiche per questo countdown sono spente.";
        else if (item.times.isEmpty()) s = "Aggiungi almeno un orario per ricevere le notifiche.";
        else if (n == 0) s = "Nessuna notifica in arrivo (la scadenza è passata).";
        else s = "Riceverai " + n + (n == 1 ? " notifica" : " notifiche") + " fino alla scadenza.\nProssima: "
                    + new SimpleDateFormat("EEEE d MMMM 'alle' HH:mm", Locale.ITALIAN).format(new Date(next));
        countTv.setText(s);
    }

    static String labelFor(int[] values, String[] labels, int v, String fallback) {
        for (int i = 0; i < values.length; i++) if (values[i] == v) return labels[i];
        return fallback;
    }

    void pickDate() {
        new DatePickerDialog(this, t.dialogTheme(), (dp, y, m, d) -> {
            item.y = y; item.m = m; item.d = d;
            refresh();
        }, item.y, item.m, item.d).show();
    }

    void pickTime(int idx) {
        int cur = idx >= 0 ? item.times.get(idx) : 9 * 60;
        new TimePickerDialog(this, t.dialogTheme(), (tp, h, mi) -> {
            int v = h * 60 + mi;
            if (idx >= 0) item.times.set(idx, v);
            else if (!item.times.contains(v)) item.times.add(v);
            refresh();
        }, cur / 60, cur % 60, true).show();
    }

    void pickPerDay() {
        String[] opts = new String[8];
        for (int i = 0; i < 8; i++) opts[i] = (i + 1) + (i == 0 ? " volta al giorno" : " volte al giorno");
        new AlertDialog.Builder(this, t.dialogTheme()).setTitle("Quante volte al giorno?")
                .setItems(opts, (d, w) -> {
                    int n = w + 1;
                    item.times.clear();
                    if (n == 1) item.times.add(9 * 60);
                    else for (int i = 0; i < n; i++) item.times.add(8 * 60 + Math.round(i * 720f / (n - 1)));
                    refresh();
                }).show();
    }

    void pickEvery() {
        new AlertDialog.Builder(this, t.dialogTheme()).setTitle("Quali giorni?")
                .setItems(EVERY_LABELS, (d, w) -> { item.everyDays = EVERY_VALUES[w]; refresh(); }).show();
    }

    void pickStart() {
        new AlertDialog.Builder(this, t.dialogTheme()).setTitle("Quando iniziare ad avvisare?")
                .setItems(START_LABELS, (d, w) -> { item.startBefore = START_VALUES[w]; refresh(); }).show();
    }

    void save() {
        String title = titleEt.getText().toString().trim();
        if (title.isEmpty()) {
            Toast.makeText(this, "Scrivi cosa devi ricordare", Toast.LENGTH_SHORT).show();
            return;
        }
        item.title = title;
        item.note = noteEt.getText().toString().trim();
        if (isNew) all.add(item);
        Store.save(this, all);
        Scheduler.reschedule(this);
        finish();
    }

    void delete() {
        Iterator<Item> i = all.iterator();
        while (i.hasNext()) if (i.next().id == item.id) i.remove();
        Store.save(this, all);
        Scheduler.reschedule(this);
        finish();
    }
}
