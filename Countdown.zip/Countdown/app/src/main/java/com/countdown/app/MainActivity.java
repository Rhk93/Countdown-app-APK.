package com.countdown.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    Theme t;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Scheduler.channel(this);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        Scheduler.reschedule(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    void build() {
        t = Theme.get(this);
        FrameLayout root = new FrameLayout(this);
        t.applyWindow(this, root);
        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(t.dp(20), t.dp(28), t.dp(20), t.dp(120));
        sv.addView(list);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        String oggi = new SimpleDateFormat("EEEE d MMMM", Locale.ITALIAN).format(new Date()).toUpperCase(Locale.ITALIAN);
        ht.addView(t.tv(oggi, 13, true, t.sub));
        ht.addView(t.tv("Countdown", 34, true, t.text));
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        TextView gear = t.tv("⚙", 22, false, t.accent);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Theme.round(t.card, t.dp(22)));
        gear.setElevation(t.dp(2));
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        head.addView(gear, new LinearLayout.LayoutParams(t.dp(44), t.dp(44)));
        list.addView(head);

        List<Item> items = Store.load(this);
        Collections.sort(items, (a, c) -> Long.compare(a.deadline().getTimeInMillis(), c.deadline().getTimeInMillis()));
        if (items.isEmpty()) {
            TextView e = t.tv("Nessun countdown.\nTocca + per aggiungerne uno.", 17, false, t.sub);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, t.dp(90), 0, 0);
            list.addView(e, new LinearLayout.LayoutParams(-1, -2));
        }
        for (Item it : items) list.addView(card(it));

        TextView fab = t.tv("+", 34, false, 0xFFFFFFFF);
        fab.setGravity(Gravity.CENTER);
        fab.setBackground(Theme.round(t.accent, t.dp(32)));
        fab.setElevation(t.dp(8));
        fab.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class)));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(t.dp(64), t.dp(64), Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, t.dp(24), t.dp(32));
        root.addView(fab, fl);
        setContentView(root);
    }

    View card(Item it) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(Theme.round(t.card, t.dp(22)));
        c.setElevation(t.dp(2));
        int p = t.dp(18);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = t.dp(14);
        c.setLayoutParams(lp);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(t.tv(it.title.isEmpty() ? "Senza titolo" : it.title, 19, true, t.text));
        left.addView(t.tv("📅 " + Scheduler.dateText(it), 14, false, t.sub));
        if (!it.note.isEmpty()) left.addView(t.tv(it.note, 14, false, t.sub));
        TextView bell = t.tv(it.summary(), 13, false, t.accent);
        bell.setPadding(0, t.dp(6), 0, 0);
        left.addView(bell);
        c.addView(left, new LinearLayout.LayoutParams(0, -2, 1));

        int dl = it.daysLeft();
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_HORIZONTAL);
        right.setPadding(t.dp(12), 0, 0, 0);
        String big = dl < 0 ? "✓" : dl == 0 ? "OGGI" : String.valueOf(dl);
        String small = dl < 0 ? "scaduto" : dl == 0 ? "scadenza" : dl == 1 ? "giorno" : "giorni";
        int color = dl < 0 ? t.sub : dl <= 3 ? 0xFFFF3B30 : t.accent;
        right.addView(t.tv(big, dl == 0 ? 24 : 38, true, color));
        right.addView(t.tv(small, 12, false, t.sub));
        c.addView(right);

        c.setOnClickListener(v -> {
            Intent in = new Intent(this, EditActivity.class);
            in.putExtra("id", it.id);
            startActivity(in);
        });
        c.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this, t.dialogTheme())
                    .setTitle("Eliminare questo countdown?")
                    .setMessage(it.title)
                    .setPositiveButton("Elimina", (d, w) -> delete(it.id))
                    .setNegativeButton("Annulla", null)
                    .show();
            return true;
        });
        return c;
    }

    void delete(long id) {
        List<Item> l = Store.load(this);
        Iterator<Item> i = l.iterator();
        while (i.hasNext()) if (i.next().id == id) i.remove();
        Store.save(this, l);
        Scheduler.reschedule(this);
        build();
    }
}
