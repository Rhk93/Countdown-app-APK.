package com.countdown.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class SettingsActivity extends Activity {
    Theme t;
    int scrollY = 0;
    ScrollView sv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    void set(String key, int v) {
        if (sv != null) scrollY = sv.getScrollY();
        Theme.prefs(this).edit().putInt(key, v).commit();
        build();
    }

    void build() {
        t = Theme.get(this);
        sv = new ScrollView(this);
        t.applyWindow(this, sv);
        LinearLayout col = t.column();
        sv.addView(col);

        LinearLayout bar = t.bar("‹ Indietro", "Impostazioni", "");
        bar.getChildAt(0).setOnClickListener(v -> finish());
        col.addView(bar);

        // STILI
        col.addView(t.label("STILE"));
        LinearLayout rowL = null;
        for (int i = 0; i < Theme.C.length; i++) {
            if (i % 3 == 0) {
                rowL = new LinearLayout(this);
                rowL.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(rowL);
            }
            rowL.addView(swatch(i));
        }

        // CARATTERE
        col.addView(t.label("CARATTERE"));
        LinearLayout gf = t.group();
        for (int i = 0; i < Theme.FONT_FAMILIES.length; i++) {
            final int idx = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(0, t.dp(13), 0, t.dp(13));
            TextView name = t.tv("Aa   " + Theme.FONT_NAMES[i], 17, false, t.text);
            name.setTypeface(Typeface.create(Theme.FONT_FAMILIES[i], Typeface.NORMAL));
            r.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            if (i == t.fontIndex) r.addView(t.tv("✓", 18, true, t.accent));
            r.setOnClickListener(v -> set("font", idx));
            if (i > 0) gf.addView(t.divider());
            gf.addView(r);
        }
        col.addView(gf);

        // GRANDEZZA
        col.addView(t.label("GRANDEZZA DEL CARATTERE"));
        LinearLayout gs = t.group();
        gs.setPadding(t.dp(16), t.dp(14), t.dp(16), t.dp(14));
        TextView perc = t.tv(Math.round(t.scale * 100) + "%", 15, true, t.accent);
        TextView prev = t.tv("Esempio: Mancano 12 giorni", 17, false, t.text);
        LinearLayout sr = new LinearLayout(this);
        sr.setOrientation(LinearLayout.HORIZONTAL);
        sr.setGravity(Gravity.CENTER_VERTICAL);
        sr.addView(t.tv("A", 13, false, t.sub));
        SeekBar sb = new SeekBar(this);
        sb.setMax(90);
        sb.setProgress(Math.round((t.scale - 0.8f) * 100));
        sb.setProgressTintList(ColorStateList.valueOf(t.accent));
        sb.setThumbTintList(ColorStateList.valueOf(t.accent));
        sr.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
        sr.addView(t.tv("A", 24, false, t.sub));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                float sc = 0.8f + p / 100f;
                perc.setText(Math.round(sc * 100) + "%");
                prev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17 * sc);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                scrollY = sv.getScrollY();
                Theme.prefs(SettingsActivity.this).edit().putFloat("scale", 0.8f + s.getProgress() / 100f).commit();
                build();
            }
        });
        gs.addView(perc);
        gs.addView(sr);
        prev.setPadding(0, t.dp(8), 0, 0);
        gs.addView(prev);
        col.addView(gs);

        // NOTIFICHE
        col.addView(t.label("NOTIFICHE"));
        LinearLayout gn = t.group();
        t.row(gn, "🔔  Prova una notifica", v -> testNotif()).setText("›");
        t.row(gn, "⚙  Permessi notifiche", v -> {
            Intent in = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            in.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(in);
        }).setText("›");
        col.addView(gn);

        TextView copy = t.tv("Countdown 1.0\nCopyright © Ignazio Paolicelli", 12, false, t.sub);
        copy.setGravity(Gravity.CENTER);
        copy.setPadding(0, t.dp(30), 0, 0);
        col.addView(copy, new LinearLayout.LayoutParams(-1, -2));

        setContentView(sv);
        final int y = scrollY;
        sv.post(() -> sv.scrollTo(0, y));
    }

    LinearLayout swatch(int i) {
        String[] c = Theme.C[i];
        int top = Color.parseColor(c[0]), bot = Color.parseColor(c[1]);
        int card = Color.parseColor(c[2]), text = Color.parseColor(c[3]), acc = Color.parseColor(c[5]);
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{top, bot});
        g.setCornerRadius(t.dp(18));
        if (i == t.index) g.setStroke(t.dp(3), t.accent);
        else g.setStroke(t.dp(1), Theme.withAlpha(t.sub, 80));
        s.setBackground(g);
        s.setPadding(t.dp(6), t.dp(12), t.dp(6), t.dp(10));

        TextView pill = t.tv("12", 18, true, acc);
        pill.setGravity(Gravity.CENTER);
        pill.setBackground(Theme.round(card, t.dp(12)));
        s.addView(pill, new LinearLayout.LayoutParams(t.dp(52), t.dp(36)));
        TextView n = t.tv(Theme.NAMES[i], 12, i == t.index, text);
        n.setGravity(Gravity.CENTER);
        n.setSingleLine(true);
        n.setPadding(0, t.dp(8), 0, 0);
        s.addView(n, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(t.dp(4), t.dp(4), t.dp(4), t.dp(4));
        s.setLayoutParams(lp);
        s.setOnClickListener(v -> set("theme", i));
        return s;
    }

    void testNotif() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
            Toast.makeText(this, "Consenti le notifiche e riprova", Toast.LENGTH_SHORT).show();
            return;
        }
        Item it = new Item();
        it.id = 999;
        it.title = "Prova Countdown";
        it.note = "Le notifiche funzionano! 🎉";
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, 3);
        it.y = c.get(Calendar.YEAR);
        it.m = c.get(Calendar.MONTH);
        it.d = c.get(Calendar.DAY_OF_MONTH);
        Scheduler.show(this, it);
    }
}
