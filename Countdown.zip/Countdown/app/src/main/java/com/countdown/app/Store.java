package com.countdown.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class Store {
    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("data", Context.MODE_PRIVATE);
    }

    public static List<Item> load(Context c) {
        List<Item> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(Item.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) { }
        return l;
    }

    public static void save(Context c, List<Item> l) {
        JSONArray a = new JSONArray();
        try {
            for (Item i : l) a.put(i.toJson());
        } catch (Exception ignored) { }
        p(c).edit().putString("items", a.toString()).commit();
    }

    public static Item find(List<Item> l, long id) {
        for (Item i : l) if (i.id == id) return i;
        return null;
    }
}
