package com.countdown.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Theme {
    public static final String[] NAMES = {
            "iOS Chiaro", "iOS Scuro", "Pesca", "Menta", "Lavanda",
            "Oceano", "Tramonto", "Notte & Oro", "Limone", "Ciliegia", "Grafite", "Aurora"
    };
    // sfondo alto, sfondo basso, scheda, testo, testo secondario, colore accento, scuro
    public static final String[][] C = {
            {"#F2F2F7", "#F2F2F7", "#FFFFFF", "#000000", "#8E8E93", "#007AFF", "0"},
            {"#000000", "#000000", "#1C1C1E", "#FFFFFF", "#8E8E93", "#0A84FF", "1"},
            {"#FFE5D9", "#FFCAD4", "#FFFFFF", "#4A2C2A", "#9C6B64", "#FF6F59", "0"},
            {"#E0F7EF", "#B8F2E6", "#FFFFFF", "#1B4332", "#52796F", "#14A098", "0"},
            {"#EDE7FF", "#D6CCFF", "#FFFFFF", "#2D1B69", "#7A6FA8", "#7B61FF", "0"},
            {"#0F2027", "#2C5364", "#CC1F3A47", "#FFFFFF", "#A9C6D3", "#4FC3F7", "1"},
            {"#FF9A8B", "#FF6A88", "#E6FFFFFF", "#3D1F2B", "#8A5A6B", "#E8457A", "0"},
            {"#0B0B0B", "#1A1A1A", "#1E1E1E", "#F5E6C4", "#A89A7A", "#D4AF37", "1"},
            {"#FFFBE6", "#FFF1A8", "#FFFFFF", "#3B3200", "#8A7D3B", "#E6A100", "0"},
            {"#FFF0F3", "#FFD6E0", "#FFFFFF", "#4A1020", "#A0606F", "#E63962", "0"},
            {"#E5E5EA", "#C7C7CC", "#F9F9FB", "#1C1C1E", "#6E6E73", "#5856D6", "0"},
            {"#141E30", "#243B55", "#CC2A3F5F", "#FFFFFF", "#B0C4DE", "#7CFFCB", "1"}
    };
    public static final String[] FONT_NAMES = {
            "Sistema", "Leggero", "Sottile", "Medio", "Stretto",
            "Serif", "Monospazio", "Informale", "Corsivo", "Maiuscoletto"
    };
    public static final String[] FONT_FAMILIES = {
            "sans-serif", "sans-serif-light", "sans-serif-thin", "sans-serif-medium", "sans-serif-condensed",
            "serif", "monospace", "casual", "cursive", "sans-serif-smallcaps"
    };

    public int bgTop, bgBottom, card, text, sub, accent, index, fontIndex;
    public boolean dark;
    public Typeface font, fontBold;
    public float scale;
    private final Context ctx;

    private Theme(Context c) { ctx = c; }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    public static Theme get(Context ctx) {
        SharedPreferences p = prefs(ctx);
        Theme t = new Theme(ctx);
        int i = p.getInt("theme", 0);
        if (i < 0 || i >= C.length) i = 0;
        int f = p.getInt("font", 0);
        if (f < 0 || f >= FONT_FAMILIES.length) f = 0;
        t.index = i;
        t.fontIndex = f;
        String[] c = C[i];
        t.bgTop = Color.parseColor(c[0]);
        t.bgBottom = Color.parseColor(c[1]);
        t.card = Color.parseColor(c[2]);
        t.text = Color.parseColor(c[3]);
        t.sub = Color.parseColor(c[4]);
        t.accent = Color.parseColor(c[5]);
        t.dark = c[6].equals("1");
        t.font = Typeface.create(FONT_FAMILIES[f], Typeface.NORMAL);
        t.fontBold = Typeface.create(FONT_FAMILIES[f], Typeface.BOLD);
        t.scale = p.getFloat("scale", 1f);
        return t;
    }

    public int dp(float v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }

    public TextView tv(String s, float sp, boolean bold, int color) {
        TextView v = new TextView(ctx);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * scale);
        v.setTypeface(bold ? fontBold : font);
        v.setTextColor(color);
        return v;
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    public static int withAlpha(int c, int a) {
        return (c & 0x00FFFFFF) | (a << 24);
    }

    @SuppressWarnings("deprecation")
    public void applyWindow(Activity a, View root) {
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{bgTop, bgBottom}));
        a.getWindow().setStatusBarColor(bgTop);
        a.getWindow().setNavigationBarColor(bgBottom);
        int flags = 0;
        if (!dark) flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        a.getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    public int dialogTheme() {
        return dark ? android.R.style.Theme_DeviceDefault_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
    }

    public TextView label(String s) {
        TextView v = tv(s, 13, false, dark ? sub : withAlpha(text, 150));
        v.setPadding(dp(16), dp(24), dp(16), dp(8));
        return v;
    }

    public LinearLayout group() {
        LinearLayout g = new LinearLayout(ctx);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(round(card, dp(16)));
        g.setPadding(dp(16), dp(2), dp(16), dp(2));
        return g;
    }

    public View divider() {
        View v = new View(ctx);
        v.setBackgroundColor(withAlpha(sub, 70));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.5f))));
        return v;
    }

    /** Riga di un gruppo: etichetta a sinistra, valore a destra. Restituisce il valore. */
    public TextView row(LinearLayout group, String label, View.OnClickListener l) {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(14), 0, dp(14));
        r.addView(tv(label, 16, false, text), new LinearLayout.LayoutParams(0, -2, 1));
        TextView v = tv("", 16, false, accent);
        r.addView(v);
        if (l != null) r.setOnClickListener(l);
        if (group.getChildCount() > 0) group.addView(divider());
        group.addView(r);
        return v;
    }

    public LinearLayout column() {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(40));
        return col;
    }

    /** Barra in alto: sinistra, titolo, destra. */
    public LinearLayout bar(String left, String title, String right) {
        LinearLayout b = new LinearLayout(ctx);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(0, dp(4), 0, dp(8));
        TextView l = tv(left, 17, false, accent);
        TextView t = tv(title, 17, true, text);
        t.setGravity(Gravity.CENTER);
        TextView r = tv(right, 17, true, accent);
        r.setGravity(Gravity.END);
        b.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
        b.addView(t, new LinearLayout.LayoutParams(0, -2, 1.4f));
        b.addView(r, new LinearLayout.LayoutParams(0, -2, 1));
        return b;
    }
}
