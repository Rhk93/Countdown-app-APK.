package com.countdown.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent in) {
        if (in.getAction() == null) {
            long now = System.currentTimeMillis();
            for (Item it : Store.load(ctx))
                if (it.nextAt > 0 && it.nextAt <= now + 60000) Scheduler.show(ctx, it);
            Scheduler.reschedule(ctx, now + 60000);
        } else {
            Scheduler.reschedule(ctx);
        }
    }
}
